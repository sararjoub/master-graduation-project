# Skills Swap — Schema للمراجعة قبل SQL Server

التصميم مبني على آخر نسخة: تعلم بين الأشخاص، Basic مجانية، Advanced وطلبات الخبراء ضمن Plus، ومسار مهني متسلسل. لا يحتوي جداول للميزات المحذوفة. هذه مواصفات وليست سكربت إنشاء قاعدة بيانات.

**التقسيم: 27 جدول عمل أساسي + 7 جداول يديرها Identity + جدولان عند ربط الدفع الحقيقي/رد الأموال.** جداول الربط الصغيرة تمنع قوائم المهارات المفصولة بفواصل وتكرار البيانات. وجود AspNetRoles لا يعيد صفحة صلاحيات الموظفين؛ نستخدم Member وAdmin فقط. وExpert اعتماد لمهارة، وPlus اشتراك، وليس أي منهما دور Admin.

## مفاتيح القراءة

- PK: مفتاح أساسي. FK: مفتاح خارجي. NULL: حقل اختياري. جميع أوقات العمل UTC بنوع datetime2(3)، وفترات التوافر المحلية مرتبطة بمنطقة المستخدم الزمنية.
- نصوص المستخدم والعربية nvarchar. المبالغ decimal(10,2)، لا float. UserId هو Guid / uniqueidentifier في كل علاقة.
- أنواع الحالات هنا أكواد نصية عليها CHECK في السكربت اللاحق؛ لا نحتاج جدول Lookup لكل قائمة صغيرة ثابتة.
- المعاملات المهمة تستخدم RowVersion والتعامل مع تعارض التحديث. RowVersion ليس تاريخًا أو رقم جلسة.
- حذف السجلات المالية والتعليمية المرتبطة ممنوع افتراضيًا بـNO ACTION. نعطل الحساب/المهارة بدل حذف تاريخها. جداول Identity المساعدة تتبع إعداد إطار العمل والمراجعة عند توليد Migration.

## الخريطة المبسطة

الحساب ← البروفايل والمهارات ← طلب تعلم ← لقاءات وتأكيدها ← تقييم.

الاشتراك المدفوع ← رصيد شهري ← حجز رصيد لطلب خبير ← اللقاء.

المستخدم ← المسار المهني ← خطوات مرتبة ← لقاءات تؤكد إنجاز الخطوة.

التفاصيل والقيود لكل جدول أدناه. الرسم الكامل في ERD.mmd، والعرض المرئي القابل للبحث في Schema.html.


## الحسابات

### AspNetUsers

حساب الدخول الوحيد للمستخدم والمشرف. لا ننشئ جدول Admins مستقلًا.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| Id | uniqueidentifier | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| UserName | nvarchar(256) | — | لا | اسم دخول؛ يمكن اعتماد البريد نفسه. |
| NormalizedUserName | nvarchar(256) | — | لا |  |
| Email | nvarchar(256) | — | لا |  |
| NormalizedEmail | nvarchar(256) | — | لا |  |
| EmailConfirmed | bit | — | لا | نعم/لا.؛ Default=0 |
| PasswordHash | nvarchar(max) | — | نعم | ينشئه Identity؛ لا تخزّن كلمة المرور الخام. |
| SecurityStamp | nvarchar(max) | — | نعم | يديره Identity. |
| ConcurrencyStamp | nvarchar(max) | — | نعم | يديره Identity. |
| PhoneNumber | nvarchar(max) | — | نعم |  |
| PhoneNumberConfirmed | bit | — | لا | نعم/لا.؛ Default=0 |
| TwoFactorEnabled | bit | — | لا | نعم/لا.؛ Default=0 |
| LockoutEnd | datetimeoffset(3) | — | نعم | يديره Identity. |
| LockoutEnabled | bit | — | لا | نعم/لا.؛ Default=1 |
| AccessFailedCount | int | — | لا | ؛ Default=0 |
| AccountStatus | varchar(24) | — | لا | Active / Suspended / Deactivated |
| StatusReason | nvarchar(500) | — | نعم |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| StatusChangedAtUtc | datetime2(3) | — | نعم | وقت UTC. |

قيود عدم التكرار المقترحة: NormalizedUserName؛ NormalizedEmail.

- تأكيد البريد قبل إرسال طلب أو حجز أو مراسلة.
- الحساب الموقوف لا ينشئ تفاعلات جديدة؛ لا نحذف سجلاته المالية أو التعليمية.

### AspNetRoles

أدوار تقنية للحماية فقط: Member وAdmin. ليست صفحة Staff permissions المحذوفة.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| Id | uniqueidentifier | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| Name | nvarchar(256) | — | لا |  |
| NormalizedName | nvarchar(256) | — | لا |  |
| ConcurrencyStamp | nvarchar(max) | — | نعم |  |

قيود عدم التكرار المقترحة: NormalizedName.

### AspNetUserRoles

ربط المستخدم بأدوار الدخول.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| UserId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetUsers.Id |
| RoleId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetRoles.Id |

### AspNetUserClaims

جدول مساعد يديره ASP.NET Core Identity.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| Id | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| UserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| ClaimType | nvarchar(max) | — | نعم |  |
| ClaimValue | nvarchar(max) | — | نعم |  |

### AspNetRoleClaims

جدول مساعد قياسي لـIdentity؛ لا يعني وجود نظام صلاحيات موظفين قابل للتحرير.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| Id | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| RoleId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetRoles.Id |
| ClaimType | nvarchar(max) | — | نعم |  |
| ClaimValue | nvarchar(max) | — | نعم |  |

### AspNetUserLogins

قد ينشئه Identity قياسيًا. يبقى فارغًا ما دام Google/GitHub ملغيين.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| LoginProvider | nvarchar(128) | PK | لا |  |
| ProviderKey | nvarchar(128) | PK | لا |  |
| ProviderDisplayName | nvarchar(256) | — | نعم |  |
| UserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |

### AspNetUserTokens

مخزن مساعد قياسي لـIdentity؛ لا ننشئ جدولًا خاصًا لكلمات المرور أو أكواد تأكيد مكشوفة.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| UserId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetUsers.Id |
| LoginProvider | nvarchar(128) | PK | لا |  |
| Name | nvarchar(128) | PK | لا |  |
| Value | nvarchar(max) | — | نعم |  |

## الملف والمهارات

### UserProfiles

الملف الشخصي للمستخدم أو الأدمن؛ صف واحد لكل حساب.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| UserId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetUsers.Id |
| DisplayName | nvarchar(80) | — | لا |  |
| Bio | nvarchar(1500) | — | نعم |  |
| AvatarStorageKey | nvarchar(500) | — | نعم | مسار ملف مُتحقق منه، وليس بيانات صورة داخل الجدول. |
| CountryCode | char(2) | — | نعم | رمز دولة يتحقق منه التطبيق. |
| City | nvarchar(100) | — | نعم |  |
| TimeZoneId | nvarchar(100) | — | لا | معرّف منطقة زمنية يدعمها السيرفر. |
| AvailabilityNote | nvarchar(300) | — | نعم | وصف اختياري للوقت المتاح. |
| UpdatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

- اكتمال الملف قيمة محسوبة من الحقول والمهارات، لا نخزن نسبة مكررة.

### Categories

التصنيفات الرئيسية الستة وقابلية إضافة المزيد.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CategoryId | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| Code | nvarchar(80) | — | لا |  |
| NameEn | nvarchar(100) | — | لا |  |
| NameAr | nvarchar(100) | — | لا |  |
| IconKey | nvarchar(100) | — | لا |  |
| SortOrder | int | — | لا | ؛ Default=0 |
| IsActive | bit | — | لا | نعم/لا.؛ Default=1 |

قيود عدم التكرار المقترحة: Code.

### SubCategories

تصنيف فرعي واحد يتبع تصنيفًا رئيسيًا واحدًا.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| SubCategoryId | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| CategoryId | int | FK | لا | مفتاح خارجي. → Categories.CategoryId |
| Code | nvarchar(100) | — | لا |  |
| NameEn | nvarchar(120) | — | لا |  |
| NameAr | nvarchar(120) | — | لا |  |
| SortOrder | int | — | لا | ؛ Default=0 |
| IsActive | bit | — | لا | نعم/لا.؛ Default=1 |

قيود عدم التكرار المقترحة: CategoryId, Code.

### Skills

موضوع يتعلمه الأشخاص، وليس كورسًا أو محتوى منشورًا.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| SkillId | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| SubCategoryId | int | FK | لا | مفتاح خارجي. → SubCategories.SubCategoryId |
| Slug | nvarchar(120) | — | لا |  |
| NameEn | nvarchar(150) | — | لا |  |
| NameAr | nvarchar(150) | — | لا |  |
| DescriptionEn | nvarchar(2000) | — | نعم |  |
| DescriptionAr | nvarchar(2000) | — | نعم |  |
| IconKey | nvarchar(100) | — | نعم | مفتاح أيقونة معتمدة من النظام، لا HTML يقدمه المستخدم. |
| LevelCode | varchar(24) | — | لا | Beginner / Intermediate / Advanced |
| AccessTier | varchar(24) | — | لا | Basic / Advanced؛ فئة مجانية أو مدفوعة مستقلة عن المستوى التعليمي. |
| IsActive | bit | — | لا | نعم/لا.؛ Default=1 |
| CreatedByUserId | uniqueidentifier | FK | نعم | مفتاح خارجي. → AspNetUsers.Id |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| UpdatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: Slug.

- الأرشفة توقف الطلبات الجديدة ولا تكسر الجلسات والسجلات القديمة.
- تفاصيل Advanced وبدء تعلمها يتطلبان Plus؛ اسم البطاقة المقفلة يمكن عرضه.
- في النسخة الأولى يمنع أرشفة مهارة لها خطوة غير منجزة في مسار حالي، حتى لا يعلق المستخدم في مسار بلا خطوة قابلة للتعلم.

### UserSkills

يربط المستخدم بمهارة يريد تعلمها أو يستطيع تعليمها أو يعرفها. صف واحد بدل قوائم مفصولة بفواصل.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| UserId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetUsers.Id |
| SkillId | int | PK | لا | مفتاح خارجي. → Skills.SkillId |
| WantsToLearn | bit | — | لا | نعم/لا.؛ Default=0 |
| CanTeach | bit | — | لا | نعم/لا.؛ Default=0 |
| KnowledgeLevel | varchar(24) | — | لا | Unknown / Beginner / Intermediate / Advanced |
| TeachingMode | varchar(16) | — | نعم | Exchange / Volunteer / Both؛ NULL إن لم يعلّم. |
| IsTeachingAvailable | bit | — | لا | نعم/لا.؛ Default=0 |
| TeachingSummary | nvarchar(500) | — | نعم |  |
| UpdatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

- على الأقل WantsToLearn أو CanTeach أو معرفة غير Unknown.
- CanTeach=1 يتطلب TeachingMode ومعرفة مناسبة؛ لا يطلب من كل مستخدم تعليم مهارة.
- تحديث مستوى المعرفة لا يثبت إنجاز خطوة مسار.

### UserAvailability

فترات التوافر الأسبوعية، ويستخدمها الخبير لعرض المواعيد الممكنة.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| AvailabilityId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| UserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| DayOfWeek | tinyint | — | لا | 0=الأحد إلى 6=السبت. |
| StartLocalTime | time(0) | — | لا |  |
| EndLocalTime | time(0) | — | لا |  |
| IsActive | bit | — | لا | نعم/لا.؛ Default=1 |

قيود عدم التكرار المقترحة: UserId, DayOfWeek, StartLocalTime, EndLocalTime.

- CHECK: DayOfWeek بين 0 و6، والبداية قبل النهاية.
- وقت محلي وفق UserProfiles.TimeZoneId؛ الجلسات الفعلية تحفظ UTC.
- منع تداخل فترات المستخدم بالتطبيق؛ تغيير المنطقة الزمنية لا ينقل جلسة محجوزة.

## الخبراء

### ExpertApplications

طلب ترقية لمهارة محددة مع قرار بشري، مع حفظ الطلبات السابقة.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| ExpertApplicationId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| ApplicantUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| SkillId | int | FK | لا | مفتاح خارجي. → Skills.SkillId |
| EvidenceRoute | varchar(24) | — | لا | Community / Portfolio |
| ExperienceYears | decimal(4,1) | — | لا |  |
| Qualifications | nvarchar(1500) | — | لا |  |
| PortfolioUrl | nvarchar(1000) | — | نعم |  |
| TeachingEvidence | nvarchar(2000) | — | لا |  |
| StatusCode | varchar(24) | — | لا | Pending / UnderReview / NeedsInfo / Approved / Rejected / Withdrawn |
| ReviewedByUserId | uniqueidentifier | FK | نعم | مفتاح خارجي. → AspNetUsers.Id |
| ReviewNote | nvarchar(2000) | — | نعم |  |
| SubmittedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| ReviewedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ClosedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: ApplicantUserId, SkillId WHERE ClosedAtUtc IS NULL؛ ExpertApplicationId, ApplicantUserId, SkillId.

- المراجع يجب أن يكون Admin.
- طلب مفتوح واحد للمستخدم والمهارة؛ التاريخ السابق لا يحذف.
- لا نثبت أرقام 10 جلسات/4.5 كتقييدات؛ شروط القبول النهائية لم تعتمد.
- CHECK: ExperienceYears>=0؛ ApplicantUserId/SkillId يرتبطان بصف UserSkills، وCanTeach يفحصه التطبيق.

### ExpertSkills

الاعتماد الفعلي للخبير في مهارة، منفصل عن اشتراكه وعن دور Admin.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| ExpertSkillId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| UserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| SkillId | int | FK | لا | مفتاح خارجي. → Skills.SkillId |
| ApprovedApplicationId | bigint | FK | لا | مفتاح خارجي. → ExpertApplications.ExpertApplicationId |
| StatusCode | varchar(24) | — | لا | Active / Suspended / Revoked |
| ApprovedByUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| ApprovedAtUtc | datetime2(3) | — | لا | وقت UTC. |
| StatusReason | nvarchar(1000) | — | نعم |  |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: UserId, SkillId؛ ApprovedApplicationId.

- المستخدم والمهارة يطابقان الطلب الموافق عليه.
- يجب وجود UserSkills للمستخدم والمهارة مع CanTeach=1.
- الاشتراك ببلس لا يجعل المستخدم خبيرًا.

## الاشتراكات

### SubscriptionPlans

الخطان Free وPlus فقط.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| PlanId | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| Code | varchar(24) | — | لا | Free / Plus |
| NameEn | nvarchar(80) | — | لا |  |
| NameAr | nvarchar(80) | — | لا |  |
| CanAccessAdvanced | bit | — | لا | نعم/لا.؛ Default=0 |
| CanBookExperts | bit | — | لا | نعم/لا.؛ Default=0 |
| ExpertCreditsPerMonth | smallint | — | لا |  |
| ExpertSessionMinutes | smallint | — | لا |  |
| IsActive | bit | — | لا | نعم/لا.؛ Default=1 |

قيود عدم التكرار المقترحة: Code.

- Free: لا Advanced ولا حجز خبراء ورصيد 0.
- القيم المعروضة للرصيد والمدة مقترحة وقابلة للاعتماد لاحقًا.

### PlanPrices

سعر الخطة والفترة؛ إضافة سعر جديد بدل تغيير سعر تاريخي استُخدم.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| PlanPriceId | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| PlanId | int | FK | لا | مفتاح خارجي. → SubscriptionPlans.PlanId |
| BillingMonths | tinyint | — | لا | 1 أو12. |
| Amount | decimal(10,2) | — | لا |  |
| Currency | char(3) | — | لا |  |
| ValidFromUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| ValidUntilUtc | datetime2(3) | — | نعم | وقت UTC. |
| IsActive | bit | — | لا | نعم/لا.؛ Default=0 |

- CHECK: Amount>=0 وBillingMonths IN (1,12).
- السعر لا يغيّر أهلية المستخدم حتى يؤكد الدفع.
- ValidUntilUtc إن وجد أكبر من ValidFromUtc؛ لا أسعار منشورة متداخلة لنفس الخطة والفترة والعملة.

### UserSubscriptions

اشتراكات Plus التاريخية؛ عدم وجود اشتراك صالح يعني Free، ولا ننشئ اشتراك Free لكل مستخدم.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| SubscriptionId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| UserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| PlanPriceId | int | FK | لا | مفتاح خارجي. → PlanPrices.PlanPriceId |
| StatusCode | varchar(24) | — | لا | Pending / Active / PastDue / Expired / Cancelled |
| StartsAtUtc | datetime2(3) | — | لا | وقت UTC. |
| PaidThroughUtc | datetime2(3) | — | لا | وقت UTC. |
| CurrentBillingStartUtc | datetime2(3) | — | لا | وقت UTC. |
| CurrentBillingEndUtc | datetime2(3) | — | لا | وقت UTC. |
| CancelAtPeriodEnd | bit | — | لا | نعم/لا.؛ Default=0 |
| CancelledAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ProviderCode | nvarchar(40) | — | نعم |  |
| ProviderSubscriptionId | nvarchar(200) | — | نعم |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |
| ExpertCreditsPerMonthSnapshot | smallint | — | لا | عدد الجلسات المتفق عليه عند الاشتراك. |
| ExpertSessionMinutesSnapshot | smallint | — | لا | مدة الجلسة عند الاشتراك. |
| CanAccessAdvancedSnapshot | bit | — | لا | نعم/لا.؛ Default=0 |
| CanBookExpertsSnapshot | bit | — | لا | نعم/لا.؛ Default=0 |

قيود عدم التكرار المقترحة: ProviderCode, ProviderSubscriptionId WHERE ProviderSubscriptionId IS NOT NULL.

- اشتراك صالح واحد يغطي وقت المستخدم، دون تداخل فترات؛ يتحقق تحت Transaction بقفل حساب المستخدم.
- الإلغاء عند نهاية الفترة لا يسحب الصلاحية المدفوعة فورًا.
- الاشتراك المنتهي لا يلغي لقاء خبير مؤكدًا سابقًا.
- مزايا Snapshot تثبت عقد الشراء، وتستخدم عند منح الرصيد وفحص الأهلية؛ تعديل الخطة لاحقًا لا يغير عقدًا سابقًا خفية.

### Payments

كل محاولة دفع أو تجديد، مع مبلغ وعملة ثابتين لهذه العملية.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| PaymentId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| SubscriptionId | bigint | FK | لا | مفتاح خارجي. → UserSubscriptions.SubscriptionId |
| Amount | decimal(10,2) | — | لا |  |
| Currency | char(3) | — | لا |  |
| StatusCode | varchar(24) | — | لا | Created / Pending / Succeeded / Failed / Cancelled |
| ProviderCode | nvarchar(40) | — | لا |  |
| ProviderPaymentId | nvarchar(200) | — | نعم |  |
| IdempotencyKey | uniqueidentifier | — | لا |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| PaidAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: IdempotencyKey؛ ProviderCode, ProviderPaymentId WHERE ProviderPaymentId IS NOT NULL.

- لا أرقام بطاقات ولا CVV ولا أسرار مزود الدفع.
- الدفع المكرر لا يمدد الاشتراك مرتين؛ نجاح الدفع وتحديث الاستحقاق عملية ذرية.
- CHECK: Amount>0 للدفع الفعلي؛ Free لا ينشئ عملية دفع.

### ExpertCreditGrants

استحقاق جلسات خبير لكل شهر خدمة، حتى للاشتراك السنوي.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CreditGrantId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| SubscriptionId | bigint | FK | لا | مفتاح خارجي. → UserSubscriptions.SubscriptionId |
| PeriodStartUtc | datetime2(3) | — | لا | وقت UTC. |
| PeriodEndUtc | datetime2(3) | — | لا | وقت UTC. |
| ExpiresAtUtc | datetime2(3) | — | لا | وقت UTC. |
| Quantity | smallint | — | لا |  |
| SessionMinutes | smallint | — | لا |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: SubscriptionId, PeriodStartUtc.

- CHECK: Quantity>0 والمدة>0 والبداية قبل النهاية.
- منح رصيد الفترة مرة واحدة فقط؛ السنوي يمنح شهريًا، لا 12 رصيدًا فورًا.
- المتاح=Quantity ناقص الحجوزات Reserved أوConsumed غير المحررة؛ لا نكرر حقل Balance.

## التعلم والتواصل

### LearningRequests

الطلب نفسه هو أصل التنسيق؛ لا يوجد كيان Agreement مستقل أو صفحة اتفاق.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| RequestId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| RequesterUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| ProviderUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| SkillId | int | FK | لا | مفتاح خارجي. → Skills.SkillId |
| OfferedSkillId | int | FK | نعم | مفتاح خارجي. → Skills.SkillId |
| ExpertSkillId | bigint | FK | نعم | مفتاح خارجي. → ExpertSkills.ExpertSkillId |
| RequestType | varchar(24) | — | لا | Exchange / Volunteer / Expert |
| StatusCode | varchar(24) | — | لا | Pending / Accepted / Rejected / Cancelled / Completed |
| GoalMessage | nvarchar(2000) | — | لا |  |
| PreferredTimeCode | varchar(24) | — | نعم | WeekdaysEvening / Weekends / Flexible؛ اختياري للخبير ذي الوقت المحدد. |
| ProposedStartUtc | datetime2(3) | — | نعم | وقت UTC. |
| ProposedEndUtc | datetime2(3) | — | نعم | وقت UTC. |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RespondedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ClosedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: RequesterUserId, ProviderUserId, SkillId WHERE ClosedAtUtc IS NULL.

- CHECK: الطالب لا يطلب من نفسه.
- Exchange يحتاج OfferedSkillId؛ Volunteer وExpert لا يحتاجان مقابلًا.
- مقدم التعليم يعرض المهارة، ومقدم العرض المقابل يستطيع تعليمها؛ يتحقق بالسيرفر.
- في Expert، ExpertSkillId مطابق لمقدم الطلب عليه والمهارة واعتماده Active.
- الطلب المفتوح المكرر يمنع؛ Accepted ليس نهاية الطلب.
- OfferedSkillId غير NULL فقط للتبادل؛ ExpertSkillId غير NULL فقط لطلب Expert.
- الوقت المقترح إما بداية ونهاية معًا أو كلاهما NULL؛ Expert يتطلب الوقتين قبل حجز الرصيد.
- الوقت المسجل في البداية ليس حجزًا مؤكدًا؛ الطلب Pending ذو حجز رصيد ساري يؤخذ بالحسبان عند فحص التعارض.

## الاشتراكات

### ExpertCreditReservations

حجز رصيد لطلب خبير، ثم استهلاكه أو تحريره دون خصم مرتين.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CreditReservationId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| CreditGrantId | bigint | FK | لا | مفتاح خارجي. → ExpertCreditGrants.CreditGrantId |
| RequestId | bigint | FK | لا | مفتاح خارجي. → LearningRequests.RequestId |
| StatusCode | varchar(24) | — | لا | Reserved / Consumed / Released |
| ReservedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| ReservationExpiresAtUtc | datetime2(3) | — | لا | وقت UTC. |
| ConsumedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ReleasedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ReleaseReason | nvarchar(500) | — | نعم |  |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: RequestId؛ CreditReservationId, RequestId.

- يخص الطالب صاحب الاشتراك، لطلب Expert فقط.
- الحجز يقفل Grant ويحسب المتاح داخل Transaction؛ الكمية لكل طلب=1.
- انتهاء طلب غير مؤكد يحرر الحجز؛ استهلاك/تحرير الرصيد لا ينفذ مرتين.
- سياسة الاسترجاع والمهلة النهائية تعتمد قبل الربط، دون Settings table.
- مهلة ReservationExpiresAtUtc تطبق على طلب Pending فقط؛ بعد قبوله يبقى الرصيد محجوزًا للقاء المؤكد، حتى لو انتهت فترة الاشتراك/المنحة لاحقًا.

## التعلم والتواصل

### LearningSessions

لقاء واحد بوقت ومشاركين ومهارة؛ للطلب التبادلي يمكن لقاء في كل اتجاه.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| SessionId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| RequestId | bigint | FK | لا | مفتاح خارجي. → LearningRequests.RequestId |
| TeacherUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| LearnerUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| SkillId | int | FK | لا | مفتاح خارجي. → Skills.SkillId |
| CreditReservationId | bigint | FK | نعم | مفتاح خارجي. → ExpertCreditReservations.CreditReservationId |
| StartsAtUtc | datetime2(3) | — | لا | وقت UTC. |
| EndsAtUtc | datetime2(3) | — | لا | وقت UTC. |
| StatusCode | varchar(24) | — | لا | Scheduled / InProgress / AwaitingConfirmation / Completed / Cancelled / NoShow |
| MeetingProvider | varchar(24) | — | لا | Chat / Zoom / External |
| ProviderMeetingId | nvarchar(200) | — | نعم |  |
| ProtectedJoinUrl | varbinary(max) | — | نعم | رابط دخول خاص محمي بالتطبيق؛ يُفك فقط للمشاركين. |
| CancelledByUserId | uniqueidentifier | FK | نعم | مفتاح خارجي. → AspNetUsers.Id |
| CancellationReason | nvarchar(500) | — | نعم |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| CompletedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |
| IdempotencyKey | uniqueidentifier | — | لا | مفتاح العملية لمنع إنشاء نفس اللقاء مرتين عند إعادة POST. |

قيود عدم التكرار المقترحة: CreditReservationId WHERE CreditReservationId IS NOT NULL؛ IdempotencyKey.

- CHECK: البداية قبل النهاية، والمعلم مختلف عن المتعلم.
- مشاركا الجلسة هما طرفا الطلب المقبول؛ المهارة هي المطلوبة أو المقابل بالاتجاه الصحيح.
- Expert يحتاج Reservation لنفس RequestId؛ لقاء واحد لكل حجز رصيد.
- منع تداخل مواعيد أي مشارك تحت Transaction وقفل مرتب لكلا الحسابين.
- لا يوجد تسجيل فيديو أو اطلاع للأدمن على رابط اللقاء.

### SessionConfirmations

تأكيد مشاركة وإنجاز كل طرف، بدل تصديق زر الإنجاز في المتصفح.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| SessionId | bigint | PK | لا | مفتاح خارجي. → LearningSessions.SessionId |
| UserId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetUsers.Id |
| Attended | bit | — | نعم | NULL حتى يجيب المستخدم. |
| CompletionConfirmedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| UpdatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |

- المسموح طرفا الجلسة فقط.
- السيرفر يكمل الجلسة بعد تحقق التأكيدين وانتهاء وقتها وشروط الإنجاز.
- تأكيد الإنجاز يتطلب Attended=1؛ المستخدم الحالي هو صاحب صف التأكيد، لا UserId يرسله العميل بحرية.

### LearningSessionChanges

طلبات تغيير موعد أو إلغاء أو توضيح مشكلة حضور لجلسة، كما في صفحة Session details؛ ليست بلاغات حسابات.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| SessionChangeId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| SessionId | bigint | FK | لا | مفتاح خارجي. → LearningSessions.SessionId |
| RequestedByUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| ChangeType | varchar(24) | — | لا | Reschedule / Cancel / AttendanceIssue |
| OriginalStartsAtUtc | datetime2(3) | — | لا | وقت UTC. |
| OriginalEndsAtUtc | datetime2(3) | — | لا | وقت UTC. |
| ProposedStartsAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ProposedEndsAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| Reason | nvarchar(1500) | — | لا |  |
| StatusCode | varchar(24) | — | لا | Pending / Accepted / Rejected / Withdrawn / Expired |
| DecisionSource | varchar(16) | — | نعم | Participant / Policy؛ NULL قبل القرار. |
| RespondedByUserId | uniqueidentifier | FK | نعم | مفتاح خارجي. → AspNetUsers.Id |
| ResponseNote | nvarchar(1000) | — | نعم |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| RespondedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ClosedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: SessionId WHERE ClosedAtUtc IS NULL.

- الطالب والمجيب طرفان في الجلسة؛ لا يستطيع طالب إعادة الجدولة الموافقة على اقتراحه بنفسه.
- Reschedule يحتاج الوقتين الجديدين وبداية قبل نهاية.
- لا تغير مواعيد الجلسة حتى قبول الطرف الآخر، ثم افحص التعارض والتوافر داخل Transaction.
- الإلغاء وتحرير الرصيد يطبقان وفق السياسة مرة واحدة؛ لا Inbox أو AccountReports لهذه العملية.

### Conversations

محادثة خاصة واحدة لكل طلب مقبول.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| ConversationId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| RequestId | bigint | FK | لا | مفتاح خارجي. → LearningRequests.RequestId |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| ClosedAtUtc | datetime2(3) | — | نعم | وقت UTC. |

قيود عدم التكرار المقترحة: RequestId.

- إنشاء المحادثة بعد القبول فقط.

### ConversationParticipants

عضوان فقط مشتقان من الطلب، مع آخر رسالة مقروءة لعداد الشات.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| ConversationId | bigint | PK | لا | مفتاح خارجي. → Conversations.ConversationId |
| UserId | uniqueidentifier | PK | لا | مفتاح خارجي. → AspNetUsers.Id |
| JoinedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| LastReadMessageId | bigint | FK | نعم | مفتاح خارجي. → Messages.MessageId |

- لا يضاف الأدمن إلى المحادثات للمراقبة.
- LastReadMessageId من نفس المحادثة.
- عداد غير المقروء خاص بالشات وليس خاصية إشعارات عامة.

### Messages

رسائل نصية خاصة؛ لا جداول مرفقات أو مجموعات في النطاق الحالي.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| MessageId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| ConversationId | bigint | FK | لا | مفتاح خارجي. → Conversations.ConversationId |
| SenderUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| Body | nvarchar(4000) | — | لا |  |
| SentAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| ClientMessageId | uniqueidentifier | — | لا | يرسله العميل لكل رسالة جديدة، ويعاد استخدامه عند إعادة إرسال نفس الرسالة. |

قيود عدم التكرار المقترحة: ConversationId, SenderUserId, ClientMessageId؛ ConversationId, MessageId.

- FK مركب إضافي (ConversationId,SenderUserId) إلى ConversationParticipants.
- Body غير فارغ؛ يُعرض بترميز HTML آمن.
- الصلاحية تعتمد على العضوية في المحادثة، لا يكفي معرفة MessageId.
- لتجنب تكرار الرسالة عند انقطاع الشبكة، أعد نفس MessageId للـClientMessageId نفسه. تسلسل الإدراج لكل محادثة يقفل صف Conversation داخل Transaction ليبقى مؤشر آخر رسالة مقروءة صحيحًا عند التزامن.

### SessionReviews

تقييم مشارك للطرف الآخر بعد لقاء مكتمل.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| ReviewId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| SessionId | bigint | FK | لا | مفتاح خارجي. → LearningSessions.SessionId |
| ReviewerUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| ReviewedUserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| Rating | tinyint | — | لا |  |
| Comment | nvarchar(1500) | — | نعم |  |
| VisibilityCode | varchar(24) | — | لا | Published / Hidden |
| ModeratedByUserId | uniqueidentifier | FK | نعم | مفتاح خارجي. → AspNetUsers.Id |
| ModerationReason | nvarchar(500) | — | نعم |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |

قيود عدم التكرار المقترحة: SessionId, ReviewerUserId.

- CHECK: Rating بين1 و5 وReviewer مختلف عنReviewed.
- الطرفان مشاركان بالجلسة وهي Completed، ولا يقيّم المستخدم لقاءه مرتين.
- الإدارة يمكنها إخفاء تقييم من صفحة Reviews؛ هذا ليس نظام Account reports.
- متوسط التقييم وعدد الجلسات يحسبان من السجلات، ولا يخزنان في Users.

## المسار المهني

### CareerGoals

أهداف البداية الستة كبيانات مرجعية؛ لا توجد صفحة Suggested skill orders ولا جداول قوالب إدارية.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CareerGoalId | int | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| Code | nvarchar(60) | — | لا |  |
| NameEn | nvarchar(150) | — | لا |  |
| NameAr | nvarchar(150) | — | لا |  |
| IsActive | bit | — | لا | نعم/لا.؛ Default=1 |

قيود عدم التكرار المقترحة: Code.

### UserCareerPaths

مسار اختاره المستخدم بعد إنشاء الخطة، مع أهدافه ومدخلاته.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CareerPathId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| UserId | uniqueidentifier | FK | لا | مفتاح خارجي. → AspNetUsers.Id |
| CareerGoalId | int | FK | لا | مفتاح خارجي. → CareerGoals.CareerGoalId |
| StartingLevel | varchar(24) | — | لا | Beginner / Intermediate / Advanced |
| TimeCommitment | varchar(24) | — | لا | Light / Moderate / Intense |
| UserRequest | nvarchar(1500) | — | نعم | طلب إرشادي اختياري، وليس محادثة خاصة كاملة. |
| SourceCode | varchar(24) | — | لا | RuleBased / AIAssisted |
| RecommendationVersion | nvarchar(80) | — | نعم |  |
| StatusCode | varchar(24) | — | لا | Active / Paused / Completed / Archived |
| IsCurrent | bit | — | لا | نعم/لا.؛ Default=1 |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| CompletedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: UserId WHERE IsCurrent=1.

- مسار حالي واحد لكل مستخدم مع حفظ القديم.
- لا PreferredLearningStyle ولا الموافقة الإدارية لكل مستخدم.
- السيرفر ينشئ المسار بـPOST ثم يعيد التوجيه إلى CareerPathId؛ لا يعتمد goal/completed من URL كبيانات موثوقة.
- StatusCode=Archived يتطلب IsCurrent=0؛ خطوات المسار تولد بترتيب متصل من1 إلىN في نفس Transaction.

### CareerPathKnownSkills

المهارات المعروفة وقت إنشاء هذا المسار، للحفاظ على مدخلات التوصية حتى لو تغير البروفايل.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CareerPathId | bigint | PK | لا | مفتاح خارجي. → UserCareerPaths.CareerPathId |
| SkillId | int | PK | لا | مفتاح خارجي. → Skills.SkillId |

### CareerPathSteps

خطوات Timeline مرتبة، كل خطوة لمهارة محددة.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CareerPathStepId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| CareerPathId | bigint | FK | لا | مفتاح خارجي. → UserCareerPaths.CareerPathId |
| SkillId | int | FK | لا | مفتاح خارجي. → Skills.SkillId |
| StepOrder | smallint | — | لا |  |
| TitleEn | nvarchar(180) | — | لا |  |
| TitleAr | nvarchar(180) | — | لا |  |
| RecommendationReasonEn | nvarchar(1000) | — | نعم |  |
| RecommendationReasonAr | nvarchar(1000) | — | نعم |  |
| RequiredCompletedSessions | smallint | — | لا | ؛ Default=1 |
| StartedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| CompletedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| RowVersion | rowversion | — | لا | لمنع فقد تحديث متزامن؛ ليس تاريخًا. |

قيود عدم التكرار المقترحة: CareerPathId, StepOrder.

- CHECK: StepOrder>0 وRequiredCompletedSessions>0.
- Locked وReady حالات محسوبة من إكمال الخطوات السابقة، وليست صلاحيات مصدرها المتصفح.
- الخطوة Advanced تحتاج فحص Plus وقت بدء تعلمها؛ عرض اسمها في المخطط لا يفتح تفاصيلها.

### CareerStepSessions

يربط إنجاز الخطوة بلقاءات حقيقية مكتملة، لا بمجرد الضغط على زر.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| CareerPathStepId | bigint | PK | لا | مفتاح خارجي. → CareerPathSteps.CareerPathStepId |
| SessionId | bigint | PK | لا | مفتاح خارجي. → LearningSessions.SessionId |
| LinkedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |

قيود عدم التكرار المقترحة: SessionId.

- Session.LearnerUserId هو مالك المسار، ومهارة الجلسة هي مهارة الخطوة.
- لا تكمل خطوة إلا بعد جلسات مكتملة كافية وتحقق كل سابقاتها.
- الجلسة نفسها لا تستخدم لإكمال خطوتين مختلفتين.

## تكامل الدفع الاختياري

### PaymentProviderEvents — مشروط بالتكامل

مطلوب عند توصيل Webhooks حقيقية لمنع معالجة حدث دفع مرتين؛ ليس Audit log إداريًا.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| ProviderEventId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| ProviderCode | nvarchar(40) | — | لا |  |
| ExternalEventId | nvarchar(200) | — | لا |  |
| EventType | nvarchar(100) | — | لا |  |
| PaymentId | bigint | FK | نعم | مفتاح خارجي. → Payments.PaymentId |
| ReceivedAtUtc | datetime2(3) | — | لا | وقت UTC. |
| ProcessedAtUtc | datetime2(3) | — | نعم | وقت UTC. |
| ProcessingState | varchar(24) | — | لا | Pending / Processed / Failed |
| ErrorCode | nvarchar(200) | — | نعم |  |

قيود عدم التكرار المقترحة: ProviderCode, ExternalEventId.

- التحقق من توقيع المزود قبل قبول الحدث، وإعادة المحاولة قابلة للتنفيذ دون تكرار الأثر.
- لا حاجة لحفظ بيانات بطاقة أو Payload حساس.

### PaymentRefunds — مشروط بالتكامل

يضاف عند اعتماد سياسة رد أموال فعلية؛ إلغاء تجديد الاشتراك لا يعني Refund تلقائيًا.

| العمود | نوع SQL Server | المفتاح | NULL؟ | الوصف / العلاقة |
|---|---|---|---|---|
| RefundId | bigint | PK | لا | المعرّف الأساسي؛ IDENTITY للأرقام، وGuid للحسابات. |
| PaymentId | bigint | FK | لا | مفتاح خارجي. → Payments.PaymentId |
| Amount | decimal(10,2) | — | لا |  |
| ProviderCode | nvarchar(40) | — | لا | يطابق مزود عملية الدفع الأصلية. |
| StatusCode | varchar(24) | — | لا | Pending / Succeeded / Failed |
| ProviderRefundId | nvarchar(200) | — | نعم |  |
| IdempotencyKey | uniqueidentifier | — | لا |  |
| Reason | nvarchar(500) | — | لا |  |
| CreatedAtUtc | datetime2(3) | — | لا | وقت UTC.؛ Default=SYSUTCDATETIME() |
| CompletedAtUtc | datetime2(3) | — | نعم | وقت UTC. |

قيود عدم التكرار المقترحة: IdempotencyKey؛ ProviderCode, ProviderRefundId WHERE ProviderRefundId IS NOT NULL.

- CHECK: Amount>0.
- مجموع المسترجعات الناجحة لا يتجاوز الدفع؛ قفل Payment داخل Transaction.

## قواعد عابرة للجداول — لا يكفي FK وحده

1. **المهارة والاشتراك:** التحقق من Plus عند عرض تفاصيل Advanced وإرسال طلب تعلمها وقبول اتجاه تبادلها. التوصية أو اسم الخطوة لا يفتحان المهارة. المعلم الذي يقدم مهارة لا يتحول إلى مشترك تلقائيًا؛ الاقتراح هنا أن الدفع مطلوب من المتعلم، وإذا كان الطرفان يتعلمان مهارتين Advanced يحتاج كلاهما أهلية Plus. يمكن تغيير هذا القرار التجاري دون تغيير الجداول.
2. **الخبير:** طالب جلسة Expert يحتاج Plus ورصيدًا ساريًا، حتى لو المهارة Basic. مقدمها معتمد لنفس المهارة. الاشتراك لا يمنح صفة خبير، والخبير لا يحصل على Plus تلقائيًا.
3. **التبادل البسيط:** RequestType=Exchange يحتفظ بالمهارة المطلوبة والمقابل في صف الطلب. اللقاءات المرتبطة تمثل اتجاه التعليم الصحيح؛ للنسخة الأولى يُؤكد إنجاز لقاء واحد لكل اتجاه، وللتطوع/الخبير لقاء واحد. ننجز الطلب آليًا بعد الوفاء بهذه الشروط، بلا Agreement table أو شاشة مستقلة. أي توسيع لعدد اللقاءات يُعتمد قبل السكربت.
4. **الحجز:** داخل Transaction، اقفل حسابي المشاركين بترتيب UserId ثابت ثم تحقق من عدم تداخل المواعيد المحجوزة. شرط التداخل: بداية موجودة أصغر من نهاية المطلوب ونهايتها أكبر من بدايته. افحص أيضًا حجوزات Expert المعلقة غير المنتهية، والتوافر والمنطقة الزمنية، ثم احجز الرصيد وسجل الطلب/الجلسة دون نافذة سباق.
5. **الرصيد:** اقفل CreditGrant، واحسب Reserved+Consumed مقابل Quantity. تأكد من مالك الاشتراك، وفترة الصلاحية، وعدم حجز نفس RequestId مرتين. عند الإلغاء/انتهاء المهلة يُحرر الحجز وفق سياسة معتمدة؛ انتهاء صلاحية المنحة لا يخلق رصيدًا قابلًا للاستخدام. لا نعدّل Payment لأن مستخدمًا ضغط زر نجاح.
6. **الإنجاز:** اللقاء يحتاج تأكيد المشاركين وشروط الوقت. يُربط بمسار المتعلم وبنفس المهارة. لا يفتح StepOrder=n إلا بعد اكتمال كل ما قبله. CompletedAtUtc لا يكتبه العميل مباشرة؛ زر المحاكاة وروابط completed في الفرونت ليست مصدر ثقة.
7. **المحادثات:** مشاركان من الطلب المقبول فقط. عضوية المستخدم تفحص في كل قراءة وإرسال، بما فيها الاتصال اللحظي. Admin لا يتجاوزها لقراءة محادثات الآخرين. LastReadMessageId يشير لرسالة في نفس المحادثة؛ يمكن إضافة FK مركب لذلك في السكربت.
8. **التقييم:** الطرف الآخر فقط بعد جلسة مكتملة، تقييم واحد من كل مشارك لكل جلسة. المتوسطات والأعداد مشتقة من المراجعات المنشورة والجلسات، ولا تمنح ترقية تلقائية.
9. **الدفع:** الاشتراك يصبح صالحًا من تأكيد السيرفر/مزود الدفع. مرجع دفع واحد وأثر استحقاق واحد لكل حدث، ومنحة واحدة لكل شهر خدمة. السعر السنوي لا يعني جلسات خبراء غير محدودة.
10. **AI:** اقتراح هدف/ترتيب/أسباب ضمن المهارات المنشورة فقط. نحفظ المسار الذي اختاره المستخدم ونسخة القواعد/التوصية. لا نحفظ كل محادثة AI أو بيانات حساسة دون حاجة. لا جداول لتمبلتات أدمن أو موافقات AI على الخبراء.

## انتقالات الحالات

- طلب تعلم: Pending → Accepted أوRejected أوCancelled. Accepted → Completed بعد إنجاز اللقاءات المطلوبة، أوCancelled وفق السياسة. المغلق يملك ClosedAtUtc.
- جلسة: Scheduled → InProgress → AwaitingConfirmation → Completed، أوCancelled/NoShow. لا يُكرر تنفيذ الاكتمال أو استهلاك الرصيد.
- طلب خبير: Pending/UnderReview/NeedsInfo → Approved أوRejected؛ ويمكن لصاحبه سحبه. Approved ينشئ/يفعل ExpertSkills داخل نفس Transaction.
- حجز رصيد: Reserved → Consumed أوReleased. لا نحول Released مباشرة إلى Consumed؛ نطلب حجزًا جديدًا عند إعادة الحجز.
- اشتراك: Pending → Active بعد الدفع. الإلغاء في نهاية الفترة يبقي الحالة والأهلية المدفوعة حتى PaidThroughUtc؛ بعدها Expired/Cancelled.

## فهارس الاستعلامات المهمة

- جميع FKs المستخدمة في القوائم، خصوصًا UserId وSkillId، مع عدم إنشاء فهرس مكرر يغطيه PK/Unique.
- Skills(SubCategoryId,IsActive,AccessTier) وUserSkills(SkillId,CanTeach,IsTeachingAvailable).
- LearningRequests(ProviderUserId,StatusCode,CreatedAtUtc) و(RequesterUserId,StatusCode,CreatedAtUtc).
- LearningSessions(TeacherUserId,StartsAtUtc) و(LearnerUserId,StartsAtUtc) مع الحالة والنهاية ضمن التغطية حسب الاستعلام.
- Messages(ConversationId,MessageId)، وSessionReviews(ReviewedUserId,VisibilityCode)، وCareerPathSteps(CareerPathId,StepOrder).
- عدم التكرار المشروط في الجداول يتحول إلى فهارس فريدة مفلترة عند كتابة SQL، مع مراجعة شروط الفلترة ونسخة SQL Server المستهدفة.

## العلاقات الخاصة والإنشاء

- UserProfiles.UserId فريد لأنه PK: علاقة User 1 : 0..1 Profile؛ خدمة التسجيل تنشئ الملف في نفس العملية ليصبح إلزاميًا وظيفيًا.
- UserSkills وAspNetUserRoles وCareerPathKnownSkills وCareerStepSessions جداول ربط many-to-many.
- Conversations.RequestId فريد: الطلب 1 : 0..1 محادثة. الرسائل متعددة.
- Sessions.CreditReservationId فريد عندما لا يكون NULL؛ الحجز يموّل جلسة خبير واحدة.
- ConversationParticipants.LastReadMessageId يصنع اعتمادًا دائريًا مع Messages. تنشأ الجداول أولًا ثم يضاف هذا FK بـALTER عند كتابة السكربت؛ يُدخل المشاركون بقيمة NULL أولًا.
- المفاتيح المركبة الموثقة في schema-model.json تربط ExpertSkills بصاحب طلب الاعتماد ومهارته، وحجز الرصيد بطلب الجلسة، ومرسل الرسالة بمشارك المحادثة، وآخر رسالة مقروءة بالمحادثة نفسها. يجب إضافتها إلى السكربت، لا الاكتفاء بوجود IDs منفردة.
- حالات السجلات وصلاحية المشترك وتعارض المواعيد وصفة Admin للمراجع تبقى شروط تطبيق/معاملة؛ لا نصفها خطأً بأنها CHECK على أعمدة جداول أخرى.

## ما لم نحوله إلى جداول

لا Notifications، ولا AccountReports، ولا SupportTickets، ولا SystemSettings/UserSettings، ولا صفحة AuditLogs/StaffPermissions، ولا ContentDrafts، ولا Courses/Lessons، ولا PreferredLearningStyle، ولا DashboardMetrics، ولا Agreement مستقل. FAQ وخلفيات الموقع واللوغو والثيم ليست بيانات عمل تحتاج جداول حاليًا. إعدادات الخدمات والأسرار في إعدادات السيرفر المحمية، لا شاشة System Settings.

## قبل إنتاج سكربت SQL

هذا تصميم مراجعة واضح، لا ادعاء بأن الباك إند أصبح منفذًا. نثبت نسخة .NET/Identity وSQL Server، ومزود الدفع، وسياسة الرصيد والإلغاء والتعويض للخبير، وآلية تأكيد إنجاز اللقاء، ثم ننتج سكربت الجداول والقيود والفهارس والبيانات المرجعية. رصيد جلسة واحدة/30 دقيقة و9 دولارات شهريًا أو84 سنويًا أمثلة التسليم السابق، وليست أسعارًا معتمدة.

مخطط Identity في السكربت النهائي يجب أن يطابق إعداد ApplicationUser : IdentityUser<Guid> وApplicationRole : IdentityRole<Guid> ونسخة Migration المختارة. لا نصنع مستخدم أدمن بكتابة PasswordHash يدويًا؛ ينشأ بـUserManager مع إعداد أولي آمن.

## مراجع تقنية

- [تخصيص نموذج ASP.NET Core Identity](https://learn.microsoft.com/en-us/aspnet/core/security/authentication/customize-identity-model?view=aspnetcore-10.0).
- [SQL Server rowversion](https://learn.microsoft.com/en-us/sql/t-sql/data-types/rowversion-transact-sql?view=sql-server-ver17).
- [SQL Server filtered indexes](https://learn.microsoft.com/en-us/sql/relational-databases/indexes/create-filtered-indexes?view=sql-server-ver17).


## شروط CHECK بصيغة واضحة للسكربت اللاحق

هذه مواصفات قيود، وليست سكربت SQL منفذًا. القواعد التي تحتاج قراءة جداول أخرى موضحة كقواعد خدمة/معاملة في القسم السابق.

### AspNetUsers

- `AccountStatus IN ('Active', 'Suspended', 'Deactivated')`

### Skills

- `LevelCode IN ('Beginner', 'Intermediate', 'Advanced')`
- `AccessTier IN ('Basic', 'Advanced')`

### UserSkills

- `CanTeach=1 OR WantsToLearn=1 OR KnowledgeLevel<>'Unknown'`
- `CanTeach=0 OR (TeachingMode IS NOT NULL AND KnowledgeLevel<>'Unknown')`
- `IsTeachingAvailable=0 OR CanTeach=1`
- `CanTeach=1 OR TeachingMode IS NULL`
- `KnowledgeLevel IN ('Unknown', 'Beginner', 'Intermediate', 'Advanced')`
- `(TeachingMode IS NULL OR TeachingMode IN ('Exchange', 'Volunteer', 'Both'))`

### UserAvailability

- `DayOfWeek BETWEEN 0 AND 6`
- `StartLocalTime < EndLocalTime`

### ExpertApplications

- `ExperienceYears >= 0`
- `(StatusCode IN ('Pending','UnderReview','NeedsInfo') AND ClosedAtUtc IS NULL) OR (StatusCode IN ('Approved','Rejected','Withdrawn') AND ClosedAtUtc IS NOT NULL)`
- `StatusCode NOT IN ('Approved','Rejected') OR (ReviewedByUserId IS NOT NULL AND ReviewedAtUtc IS NOT NULL AND ReviewNote IS NOT NULL)`
- `EvidenceRoute IN ('Community', 'Portfolio')`
- `StatusCode IN ('Pending', 'UnderReview', 'NeedsInfo', 'Approved', 'Rejected', 'Withdrawn')`

### ExpertSkills

- `StatusCode='Active' OR StatusReason IS NOT NULL`
- `StatusCode IN ('Active', 'Suspended', 'Revoked')`

### SubscriptionPlans

- `ExpertCreditsPerMonth>=0`
- `ExpertSessionMinutes>=0`
- `Code<>'Free' OR (CanAccessAdvanced=0 AND CanBookExperts=0 AND ExpertCreditsPerMonth=0)`
- `CanBookExperts=0 OR (ExpertCreditsPerMonth>0 AND ExpertSessionMinutes>0)`
- `Code IN ('Free', 'Plus')`

### PlanPrices

- `BillingMonths IN (1,12)`
- `Amount>=0`
- `ValidUntilUtc IS NULL OR ValidUntilUtc>ValidFromUtc`

### UserSubscriptions

- `PaidThroughUtc>=StartsAtUtc`
- `CurrentBillingEndUtc>CurrentBillingStartUtc`
- `ExpertCreditsPerMonthSnapshot>=0`
- `ExpertSessionMinutesSnapshot>=0`
- `CanBookExpertsSnapshot=0 OR (ExpertCreditsPerMonthSnapshot>0 AND ExpertSessionMinutesSnapshot>0)`
- `StatusCode IN ('Pending', 'Active', 'PastDue', 'Expired', 'Cancelled')`

### Payments

- `Amount>0`
- `StatusCode<>'Succeeded' OR PaidAtUtc IS NOT NULL`
- `StatusCode IN ('Created', 'Pending', 'Succeeded', 'Failed', 'Cancelled')`

### ExpertCreditGrants

- `Quantity>0`
- `SessionMinutes>0`
- `PeriodEndUtc>PeriodStartUtc`
- `ExpiresAtUtc>=PeriodEndUtc`

### LearningRequests

- `RequesterUserId<>ProviderUserId`
- `(RequestType='Exchange' AND OfferedSkillId IS NOT NULL) OR (RequestType<>'Exchange' AND OfferedSkillId IS NULL)`
- `(RequestType='Expert' AND ExpertSkillId IS NOT NULL) OR (RequestType<>'Expert' AND ExpertSkillId IS NULL)`
- `(ProposedStartUtc IS NULL AND ProposedEndUtc IS NULL) OR (ProposedStartUtc IS NOT NULL AND ProposedEndUtc IS NOT NULL AND ProposedEndUtc>ProposedStartUtc)`
- `RequestType<>'Expert' OR (ProposedStartUtc IS NOT NULL AND ProposedEndUtc IS NOT NULL)`
- `(StatusCode IN ('Pending','Accepted') AND ClosedAtUtc IS NULL) OR (StatusCode IN ('Rejected','Cancelled','Completed') AND ClosedAtUtc IS NOT NULL)`
- `RequestType IN ('Exchange', 'Volunteer', 'Expert')`
- `StatusCode IN ('Pending', 'Accepted', 'Rejected', 'Cancelled', 'Completed')`
- `(PreferredTimeCode IS NULL OR PreferredTimeCode IN ('WeekdaysEvening', 'Weekends', 'Flexible'))`

### ExpertCreditReservations

- `(StatusCode='Reserved' AND ConsumedAtUtc IS NULL AND ReleasedAtUtc IS NULL) OR (StatusCode='Consumed' AND ConsumedAtUtc IS NOT NULL AND ReleasedAtUtc IS NULL) OR (StatusCode='Released' AND ReleasedAtUtc IS NOT NULL AND ConsumedAtUtc IS NULL)`
- `ReservationExpiresAtUtc>ReservedAtUtc`
- `StatusCode IN ('Reserved', 'Consumed', 'Released')`

### LearningSessions

- `TeacherUserId<>LearnerUserId`
- `EndsAtUtc>StartsAtUtc`
- `StatusCode<>'Completed' OR CompletedAtUtc IS NOT NULL`
- `StatusCode IN ('Scheduled', 'InProgress', 'AwaitingConfirmation', 'Completed', 'Cancelled', 'NoShow')`
- `MeetingProvider IN ('Chat', 'Zoom', 'External')`

### SessionConfirmations

- `CompletionConfirmedAtUtc IS NULL OR (Attended IS NOT NULL AND Attended=1)`

### LearningSessionChanges

- `OriginalEndsAtUtc>OriginalStartsAtUtc`
- `(ChangeType='Reschedule' AND ProposedStartsAtUtc IS NOT NULL AND ProposedEndsAtUtc IS NOT NULL AND ProposedEndsAtUtc>ProposedStartsAtUtc) OR (ChangeType<>'Reschedule' AND ProposedStartsAtUtc IS NULL AND ProposedEndsAtUtc IS NULL)`
- `(StatusCode='Pending' AND ClosedAtUtc IS NULL) OR (StatusCode<>'Pending' AND ClosedAtUtc IS NOT NULL)`
- `StatusCode NOT IN ('Accepted','Rejected') OR (RespondedAtUtc IS NOT NULL AND DecisionSource IS NOT NULL)`
- `ChangeType IN ('Reschedule', 'Cancel', 'AttendanceIssue')`
- `StatusCode IN ('Pending', 'Accepted', 'Rejected', 'Withdrawn', 'Expired')`
- `(DecisionSource IS NULL OR DecisionSource IN ('Participant', 'Policy'))`

### Messages

- `LEN(LTRIM(RTRIM(Body)))>0`

### SessionReviews

- `Rating BETWEEN 1 AND 5`
- `ReviewerUserId<>ReviewedUserId`
- `VisibilityCode<>'Hidden' OR (ModeratedByUserId IS NOT NULL AND ModerationReason IS NOT NULL)`
- `VisibilityCode IN ('Published', 'Hidden')`

### UserCareerPaths

- `StatusCode<>'Archived' OR IsCurrent=0`
- `StatusCode<>'Completed' OR CompletedAtUtc IS NOT NULL`
- `StartingLevel IN ('Beginner', 'Intermediate', 'Advanced')`
- `TimeCommitment IN ('Light', 'Moderate', 'Intense')`
- `SourceCode IN ('RuleBased', 'AIAssisted')`
- `StatusCode IN ('Active', 'Paused', 'Completed', 'Archived')`

### CareerPathSteps

- `StepOrder>0`
- `RequiredCompletedSessions>0`
- `CompletedAtUtc IS NULL OR (StartedAtUtc IS NOT NULL AND CompletedAtUtc>=StartedAtUtc)`

### PaymentProviderEvents

- `ProcessingState IN ('Pending', 'Processed', 'Failed')`

### PaymentRefunds

- `Amount>0`
- `StatusCode IN ('Pending', 'Succeeded', 'Failed')`
